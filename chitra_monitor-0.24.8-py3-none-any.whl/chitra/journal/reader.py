"""Incremental JSONL reader with byte-accurate rotation handling."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO

from .models import ByteRange, RawRecord, TranscriptIdentity

DEFAULT_MAX_BATCH_BYTES = 1024 * 1024
_PARTIAL_MEMORY_BYTES = 64 * 1024


@dataclass(frozen=True)
class Rotation:
    previous: TranscriptIdentity
    current: TranscriptIdentity
    abandoned_partial_bytes: int


@dataclass(frozen=True)
class ReadBatch:
    records: tuple[RawRecord, ...]
    rotations: tuple[Rotation, ...] = ()


class JsonlTailReader:
    """Read only completed lines while retaining partial append bytes."""

    def __init__(self, path: Path, *, chunk_size: int = 64 * 1024, max_batch_bytes: int | None = None) -> None:
        if chunk_size < 1:
            raise ValueError("chunk_size must be positive")
        self.path = path
        self.chunk_size = chunk_size
        if max_batch_bytes is not None and max_batch_bytes < 1:
            raise ValueError("max_batch_bytes must be positive")
        self.max_batch_bytes = max_batch_bytes
        # A record may span batches; cap partial buffering separately from poll work.
        self.max_record_bytes = max_batch_bytes * 8 if max_batch_bytes is not None else None
        self._handle: BinaryIO | None = None
        self._identity: TranscriptIdentity | None = None
        self._offset = 0
        self._buffer = self._new_buffer()
        self._pending_bytes = 0
        self._buffer_start = 0
        self._generation = 0
        self._anchor = b""
        # Running digest over every consumed byte in [0, _buffer_start):
        # one hash object replaces a per-line digest list while detecting the
        # same interior rewrites.
        self._consumed_digest = hashlib.sha256()
        # Mtime observed at the last completed read of this file. A poll that
        # finds size and mtime both untouched proves no byte moved, so the
        # integrity scan has nothing to re-verify and the poll is O(1).
        self._last_mtime_ns: int | None = None

    @property
    def identity(self) -> TranscriptIdentity | None:
        return self._identity

    @property
    def offset(self) -> int:
        return self._offset

    @property
    def pending_bytes(self) -> int:
        return self._pending_bytes

    def close(self) -> None:
        self._close_handle()
        self._buffer.close()

    def _close_handle(self) -> None:
        if self._handle is not None:
            self._handle.close()
        self._handle = None

    @staticmethod
    def _new_buffer() -> BinaryIO:
        return tempfile.SpooledTemporaryFile(max_size=_PARTIAL_MEMORY_BYTES, mode="w+b")

    def _reset_buffer(self) -> None:
        self._buffer.close()
        self._buffer = self._new_buffer()
        self._pending_bytes = 0

    def _append_buffer(self, data: bytes) -> None:
        self._buffer.seek(0, os.SEEK_END)
        self._buffer.write(data)
        self._pending_bytes += len(data)

    def _take_buffer(self) -> bytes:
        self._buffer.seek(0)
        data = self._buffer.read(self._pending_bytes)
        self._buffer.seek(0)
        self._buffer.truncate()
        self._pending_bytes = 0
        return data

    def __enter__(self) -> JsonlTailReader:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def poll(self) -> ReadBatch:
        if self._buffer.closed:
            raise ValueError("reader is closed")
        rotations: list[Rotation] = []
        if self._handle is None:
            if not self.path.exists():
                return ReadBatch(())
            self._open_current()

        path_stat = self._safe_stat()
        assert self._identity is not None
        if path_stat is None:
            return ReadBatch(tuple(self._drain()))

        current_key = (self._identity.device, self._identity.inode)
        path_key = (path_stat.st_dev, path_stat.st_ino)
        replaced = path_key != current_key
        if (
            not replaced
            and path_stat.st_size == self._offset
            and path_stat.st_mtime_ns == self._last_mtime_ns
        ):
            # Same file, no new bytes, mtime unmoved: nothing was appended or
            # rewritten since the last read, so there is nothing to drain or
            # re-verify. This is the steady-state poll and it stays O(1).
            return ReadBatch(())
        rewritten = path_key == current_key and (
            path_stat.st_size < self._offset or not self._anchor_matches()
            or (path_stat.st_mtime_ns != self._last_mtime_ns and not self._consumed_intact())
        )
        records = self._drain() if replaced else []
        if replaced or rewritten:
            previous = self._identity
            abandoned = self._pending_bytes
            self._close_handle()
            self._reset_buffer()
            self._generation += 1
            self._offset = 0
            self._buffer_start = 0
            self._anchor = b""
            self._consumed_digest = hashlib.sha256()
            self._open_current()
            assert self._identity is not None
            rotations.append(Rotation(previous, self._identity, abandoned))
            records.extend(self._drain())
        elif not replaced:
            records.extend(self._drain())

        # Catch a rename that raced the read above. The old descriptor is
        # already drained, so switching now loses no completed record.
        final_stat = self._safe_stat()
        assert self._identity is not None
        if final_stat is not None and (final_stat.st_dev, final_stat.st_ino) != (
            self._identity.device,
            self._identity.inode,
        ):
            previous = self._identity
            abandoned = self._pending_bytes
            self._close_handle()
            self._reset_buffer()
            self._generation += 1
            self._offset = 0
            self._buffer_start = 0
            self._anchor = b""
            self._consumed_digest = hashlib.sha256()
            self._open_current()
            assert self._identity is not None
            rotations.append(Rotation(previous, self._identity, abandoned))
            records.extend(self._drain())
        if final_stat is not None:
            self._last_mtime_ns = final_stat.st_mtime_ns
        return ReadBatch(tuple(records), tuple(rotations))

    def follow(
        self,
        *,
        stop: Callable[[], bool] | None = None,
        poll_interval: float = 0.1,
    ) -> Iterator[ReadBatch]:
        """Yield append or rotation batches until a caller-controlled stop.

        There is deliberately no elapsed-time cutoff or lease expiry. With no
        ``stop`` callback this iterator follows the path indefinitely.
        """
        if poll_interval < 0:
            raise ValueError("poll_interval cannot be negative")
        while stop is None or not stop():
            batch = self.poll()
            if batch.records or batch.rotations:
                yield batch
            elif poll_interval:
                time.sleep(poll_interval)

    def _safe_stat(self) -> os.stat_result | None:
        try:
            return self.path.stat()
        except FileNotFoundError:
            return None

    def _open_current(self) -> None:
        handle = self.path.open("rb")
        file_stat = os.fstat(handle.fileno())
        self._handle = handle
        self._identity = TranscriptIdentity(
            path=str(self.path),
            device=file_stat.st_dev,
            inode=file_stat.st_ino,
            generation=self._generation,
        )
        self._last_mtime_ns = file_stat.st_mtime_ns

    def _anchor_matches(self) -> bool:
        if not self._anchor:
            return True
        assert self._handle is not None
        start = self._offset - len(self._anchor)
        return os.pread(self._handle.fileno(), len(self._anchor), start) == self._anchor

    def _consumed_intact(self) -> bool:
        """Verify earlier record bytes and the buffered tail still match disk."""
        assert self._handle is not None
        if self._pending_bytes:
            self._buffer.seek(0)
            position = 0
            while position < self._pending_bytes:
                expected = self._buffer.read(min(self.chunk_size, self._pending_bytes - position))
                if not expected or os.pread(self._handle.fileno(), len(expected), self._buffer_start + position) != expected:
                    return False
                position += len(expected)
        hasher = hashlib.sha256()
        position = 0
        while position < self._buffer_start:
            chunk = os.pread(
                self._handle.fileno(),
                min(self.chunk_size, self._buffer_start - position),
                position,
            )
            if not chunk:
                return False
            hasher.update(chunk)
            position += len(chunk)
        return hasher.digest() == self._consumed_digest.digest()

    def _drain(self) -> list[RawRecord]:
        assert self._handle is not None
        assert self._identity is not None
        records: list[RawRecord] = []
        drained_bytes = 0
        while True:
            if self.max_batch_bytes is not None and drained_bytes >= self.max_batch_bytes:
                break
            chunk = self._handle.read(self.chunk_size)
            if not chunk:
                break
            chunk_start = self._offset
            drained_bytes += len(chunk)
            self._offset += len(chunk)
            self._anchor = (self._anchor + chunk)[-64:]
            position = 0
            while position < len(chunk):
                newline = chunk.find(b"\n", position)
                end = newline + 1 if newline >= 0 else len(chunk)
                if not self._pending_bytes:
                    self._buffer_start = chunk_start + position
                self._append_buffer(chunk[position:end])
                if newline < 0:
                    if self.max_record_bytes is not None and self._pending_bytes > self.max_record_bytes:
                        raise ValueError(f"transcript record exceeds {self.max_record_bytes} bytes at {self.path}:{self._buffer_start}")
                    break
                if self.max_record_bytes is not None and self._pending_bytes > self.max_record_bytes:
                    raise ValueError(f"transcript record exceeds {self.max_record_bytes} bytes at {self.path}:{self._buffer_start}")
                raw_line = self._take_buffer()
                line_start = self._buffer_start
                line_end = line_start + len(raw_line)
                self._buffer_start = line_end
                if raw_line.strip():
                    records.append(self._decode(raw_line, line_start, line_end))
                else:
                    self._consumed_digest.update(raw_line)
                position = end
        return records

    def _decode(self, raw_line: bytes, start: int, end: int) -> RawRecord:
        digest = hashlib.sha256(raw_line).hexdigest()
        record: dict[str, Any] | None = None
        error: str | None = None
        try:
            value = json.loads(raw_line)
            if isinstance(value, dict):
                record = value
            else:
                error = "record is not a JSON object"
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            error = str(exc)
        assert self._identity is not None
        self._consumed_digest.update(raw_line)
        return RawRecord(
            transcript=self._identity,
            byte_range=ByteRange(start=start, end=end),
            raw_sha256=digest,
            record=record,
            decode_error=error,
        )
