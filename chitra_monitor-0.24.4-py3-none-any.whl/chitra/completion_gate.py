"""Forced, citation-bearing completion review for watched agent turns."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from typing import Literal, Protocol, cast

from pydantic import BaseModel, ConfigDict, Field, field_validator

from chitra.lexicon import (
    COMPLETION_CLAIM_RE,
    COMPLETION_DEFERRAL_PHRASES,
    COMPLETION_EVIDENCE_FAILURE_RE,
    COMPLETION_EVIDENCE_LIVE_RESULT_RE,
    COMPLETION_EVIDENCE_PATH_RE,
    COMPLETION_EVIDENCE_PR_RE,
    COMPLETION_EVIDENCE_SHA_RE,
    COMPLETION_NEGATION_RE,
)
from chitra.policy_config import INCIDENT_COMPLETION_DEFERRAL_PHRASES, GatePolicy

# Fallback for callers that scan without a GatePolicy: the shipped default
# vocabulary, including the incident phrases that live in policy config.
_DEFERRAL_PHRASES = COMPLETION_DEFERRAL_PHRASES + INCIDENT_COMPLETION_DEFERRAL_PHRASES


class TodoItem(BaseModel):
    text: str
    status: str
    id: str | None = None
    validator: str | None = None
    required_receipt: str | None = None


EvidenceKind = Literal["artifact", "deploy", "live_verify", "merged_pr", "failure"]


class CompletionEvidence(BaseModel):
    """One claimed proof item with the exact citation retained."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: EvidenceKind = "artifact"
    citation: str = Field(min_length=1)
    todo_item: str | None = None
    done_when_item_id: str | None = None
    receipt_name: str | None = None
    validator: str | None = None
    validator_result: Literal["pass", "fail"] | None = None

    @field_validator("citation")
    @classmethod
    def citation_is_not_whitespace(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("evidence citation must be non-empty")
        return value.strip()

    @field_validator("todo_item", "done_when_item_id", "receipt_name", "validator")
    @classmethod
    def optional_strings_are_not_whitespace(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.strip():
            raise ValueError("optional evidence bindings must be non-empty when present")
        return value.strip()


class EnrolledDoneWhenItemLike(Protocol):
    @property
    def id(self) -> str: ...

    @property
    def text(self) -> str: ...

    @property
    def validator(self) -> str: ...

    @property
    def required_receipt(self) -> str: ...


def completion_receipt_issues(
    enrolled_items: Sequence[EnrolledDoneWhenItemLike],
    evidence: Sequence[CompletionEvidence],
    *,
    verified_results: Mapping[str, str] | None = None,
) -> list[str]:
    """Return exact item, receipt, validator, result, and citation gaps.

    When ``verified_results`` is provided it maps receipt names to the
    results stored on disk by Chitra's own validator execution; claimed
    ``validator_result`` values are then ignored entirely.
    """

    def _result_passes(proof: CompletionEvidence) -> bool:
        if verified_results is None:
            return proof.validator_result == "pass"
        return verified_results.get(proof.receipt_name or "") == "pass"

    issues: list[str] = []
    for item in enrolled_items:
        item_proofs = [proof for proof in evidence if proof.done_when_item_id == item.id]
        if not item_proofs:
            issues.append(f"done item {item.id!r} has no completion receipt")
            continue
        named = [proof for proof in item_proofs if proof.receipt_name == item.required_receipt]
        if not named:
            issues.append(f"done item {item.id!r} requires receipt {item.required_receipt!r}")
            continue
        validated = [proof for proof in named if proof.validator == item.validator]
        if not validated:
            issues.append(f"done item {item.id!r} requires validator {item.validator!r}")
            continue
        passing = [proof for proof in validated if _result_passes(proof) and evidence_is_concrete(proof)]
        if not passing:
            issues.append(f"done item {item.id!r} has no passing validator result with a concrete citation")
    return issues


def require_completion_receipts(
    enrolled_items: Sequence[EnrolledDoneWhenItemLike],
    evidence: Sequence[CompletionEvidence],
) -> None:
    """Raise before a done transition when any frozen item lacks its receipt."""
    if not enrolled_items:
        raise ValueError("completion requires at least one frozen done item")
    issues = completion_receipt_issues(enrolled_items, evidence)
    if issues:
        raise ValueError("; ".join(issues))


class CompletionAudit(BaseModel):
    verdict: Literal["CLEAN", "COMPLETION_DISPUTE"]
    todo_residue: list[str]
    deferral_matches: list[dict[str, str]]
    evidence_gap: bool
    invalid_evidence: list[str]
    per_item_evidence_gap: list[str]
    posture_mismatch: bool
    summary: str


def is_completion_claim(text: str) -> bool:
    """Return whether a completed turn adopts a literal completion posture.

    The single shared claim vocabulary: a line anchored by
    ``COMPLETION_CLAIM_RE`` counts unless the same line negates it
    (``COMPLETION_NEGATION_RE``), so "the work is done, tests remain to
    run" still claims while "still working; not done" does not.
    """
    return any(
        COMPLETION_CLAIM_RE.search(line) and not COMPLETION_NEGATION_RE.search(line)
        for line in text.splitlines()
    )


def check_todo_residue(todo_items: list[TodoItem], *, complete_statuses: Sequence[str] = ("done",)) -> list[str]:
    return [item.text for item in todo_items if item.status not in complete_statuses]


def scan_deferral_language(
    text: str,
    *,
    phrases: Sequence[str] | None = None,
) -> list[dict[str, str]]:
    lowered = text.lower()
    matches: list[dict[str, str]] = []
    for phrase in phrases if phrases is not None else _DEFERRAL_PHRASES:
        if phrase.lower() in lowered:
            matches.append({"phrase": phrase, "code": "DEFERRAL_STUB"})
    return matches


def evidence_is_concrete(evidence: CompletionEvidence) -> bool:
    """Reject labels/assertions that contain no independently locatable fact."""
    citation = evidence.citation
    if evidence.kind == "deploy":
        return COMPLETION_EVIDENCE_SHA_RE.search(citation) is not None
    if evidence.kind == "live_verify":
        return COMPLETION_EVIDENCE_PATH_RE.search(citation) is not None or COMPLETION_EVIDENCE_LIVE_RESULT_RE.search(citation) is not None
    if evidence.kind == "artifact":
        return COMPLETION_EVIDENCE_PATH_RE.search(citation) is not None
    if evidence.kind == "merged_pr":
        return COMPLETION_EVIDENCE_PR_RE.search(citation) is not None
    return COMPLETION_EVIDENCE_PATH_RE.search(citation) is not None or COMPLETION_EVIDENCE_FAILURE_RE.search(citation) is not None


def extract_completion_evidence(text: str) -> list[CompletionEvidence]:
    """Extract exact cited lines from a pane turn without converting claims to booleans."""
    evidence: list[CompletionEvidence] = []
    seen: set[tuple[str, str, str | None, str | None]] = set()
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        structured = _parse_structured_completion_evidence(line)
        if structured is not None:
            key = (structured.kind, structured.citation, structured.done_when_item_id, structured.receipt_name)
            if key not in seen:
                evidence.append(structured)
                seen.add(key)
            continue
        kinds: list[EvidenceKind] = []
        if COMPLETION_EVIDENCE_PR_RE.search(line):
            kinds.append("merged_pr")
        if COMPLETION_EVIDENCE_SHA_RE.search(line) and re.search(r"\b(deploy|release|sha|commit)\b", line, re.I):
            kinds.append("deploy")
        if COMPLETION_EVIDENCE_LIVE_RESULT_RE.search(line) or (
            re.search(r"\blive[- ]?verif", line, re.I) and COMPLETION_EVIDENCE_PATH_RE.search(line)
        ):
            kinds.append("live_verify")
        if COMPLETION_EVIDENCE_PATH_RE.search(line) and re.search(
            r"\b(proof|artifact|screenshot|record|log|report)\b", line, re.I
        ):
            kinds.append("artifact")
        if COMPLETION_EVIDENCE_FAILURE_RE.search(line):
            kinds.append("failure")
        for kind in kinds:
            key = (kind, line, None, None)
            if key not in seen:
                evidence.append(CompletionEvidence(kind=kind, citation=line))
                seen.add(key)
    return evidence


def _parse_structured_completion_evidence(line: str) -> CompletionEvidence | None:
    """Read one JSON completion proof, optionally after a stable text prefix."""
    payload_text = line
    for prefix in ("CHITRA-COMPLETION:", "CHITRA_COMPLETION:"):
        if line.startswith(prefix):
            payload_text = line[len(prefix) :].strip()
            break
    if not payload_text.startswith("{"):
        return None
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or not {
        "done_when_item_id",
        "receipt_name",
        "validator",
        "validator_result",
        "citation",
    }.issubset(payload):
        return None
    # The lane's JSON line is only a trigger and an item binding: its own
    # validator_result is discarded because only Chitra's executed and stored
    # result may establish a pass.
    payload = {key: value for key, value in payload.items() if key != "validator_result"}
    payload.setdefault("kind", "artifact")
    try:
        return CompletionEvidence.model_validate(payload)
    except ValueError:
        return None


def has_structured_completion_line(text: str) -> bool:
    """Return whether any pane line carries a structured completion payload."""
    return any(
        _parse_structured_completion_evidence(raw_line.strip()) is not None for raw_line in text.splitlines()
    )


def evaluate_completion_claim(
    todo_items: list[TodoItem],
    transcript_text: str,
    evidence: Sequence[CompletionEvidence],
    *,
    policy: GatePolicy | None = None,
    open_asks: Sequence[str] = (),
    blockers: Sequence[str] = (),
    verified_results: Mapping[str, str] | None = None,
) -> CompletionAudit:
    """Require cited deploy/live proof and an honest completion posture."""
    if policy is None:
        policy = GatePolicy()
    todo_residue = check_todo_residue(todo_items, complete_statuses=policy.complete_todo_statuses)
    deferral_matches = scan_deferral_language(transcript_text, phrases=policy.deferral_phrases)
    invalid_evidence = [item.citation for item in evidence if not evidence_is_concrete(item)]
    valid = [item for item in evidence if evidence_is_concrete(item)]
    valid_kinds = {item.kind for item in valid}
    missing_evidence: list[str] = []
    if "deploy" in policy.required_evidence and "deploy" not in valid_kinds:
        missing_evidence.append("deploy evidence citation")
    if "live_verify" in policy.required_evidence and "live_verify" not in valid_kinds:
        missing_evidence.append("live-verify evidence citation")
    evidence_gap = bool(missing_evidence or invalid_evidence)
    per_item_evidence_gap: list[str] = []
    for item in todo_items:
        if item.status not in policy.complete_todo_statuses:
            continue
        if item.id is None:
            if not any(proof.todo_item == item.text for proof in valid):
                per_item_evidence_gap.append(item.text)
            continue
        if not item.validator or not item.required_receipt:
            per_item_evidence_gap.append(item.text)
            continue
        if completion_receipt_issues((cast(EnrolledDoneWhenItemLike, item),), valid, verified_results=verified_results):
            per_item_evidence_gap.append(item.text)
    blocked_todos = [item.text for item in todo_items if item.status.lower() in {"blocked", "stalled"}]
    posture_mismatch = bool(blocked_todos and not open_asks and not blockers)

    clean = not (todo_residue or deferral_matches or evidence_gap or per_item_evidence_gap or posture_mismatch)
    if clean:
        return CompletionAudit(
            verdict="CLEAN",
            todo_residue=[],
            deferral_matches=[],
            evidence_gap=False,
            invalid_evidence=[],
            per_item_evidence_gap=[],
            posture_mismatch=False,
            summary="clean: cited deploy and live verification evidence and per-item proof validate",
        )

    gaps: list[str] = []
    if todo_residue:
        gaps.append(f"{len(todo_residue)} non-done todo item(s): {todo_residue!r}")
    if deferral_matches:
        gaps.append(f"deferral language detected: {[match['phrase'] for match in deferral_matches]!r}")
    if missing_evidence:
        gaps.append("missing " + ", ".join(missing_evidence))
    if invalid_evidence:
        gaps.append(f"bare or non-concrete evidence assertions: {invalid_evidence!r}")
    if per_item_evidence_gap:
        gaps.append(f"missing per-item verification: {per_item_evidence_gap!r}")
    if posture_mismatch:
        gaps.append(f"blocked todo posture has no open ask or blocker: {blocked_todos!r}")
    return CompletionAudit(
        verdict="COMPLETION_DISPUTE",
        todo_residue=todo_residue,
        deferral_matches=deferral_matches,
        evidence_gap=evidence_gap,
        invalid_evidence=invalid_evidence,
        per_item_evidence_gap=per_item_evidence_gap,
        posture_mismatch=posture_mismatch,
        summary="completion dispute: " + "; ".join(gaps),
    )



